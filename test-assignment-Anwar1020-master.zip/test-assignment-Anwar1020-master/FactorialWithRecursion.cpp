#include<iostream>
using namespace std;
/**
 * Impelment this function so that it could find the factorial
 * of n using recursion.
 */
int fact(int n)
{
  
}

int main()
{
  int x;
  while(cin >> x)
  {
    cout << x << "! = " << fact(x) << endl;
  }
  return 0;
}
